﻿using UnityEngine;
using System.Collections;

public class CharacterBehavior : MonoBehaviour {
	public float speed = 10F;
	public float jumpSpeed = 8.0F;
	public float gravity = 30.0F;
	public float zDepthSpeed = 0.75F;

	private float zCardinality = 0.33f;
	private float scale = 0.33f;

	private Vector3 moveDirection = Vector3.zero;
	private Animator animator;
	private CharacterController controller;

	void Start()
	{
		animator = this.GetComponent<Animator>();
		controller = this.GetComponent<CharacterController>();
	}
	void Update() {
		bool isMoving = false;
		float vertical = Input.GetAxis("LeftAnalogZ");
		if ((vertical < scale) && (-scale < vertical)) {
			vertical = 0f;
		}
		float horizontal = Input.GetAxis("LeftAnalogX");
		if ((horizontal < scale) && (-scale < horizontal)) {
			horizontal = 0f;
		}
		/*if ((vertical != 0) || (horizontal != 0)) {
			isMoving = true;
			animator.SetBool("isWalking", true);
		} else {
			isMoving = false;
			animator.SetBool("isWalking", false);
		}
		if (isMoving) 
		{
			if(vertical <= 0)
			{
				if(horizontal >= zCardinality)
				{
					animator.SetInteger ("Direction", 4);
				}
				else if (horizontal <= -zCardinality)
				{
					animator.SetInteger ("Direction", 0);
				}
				else if ((horizontal < zCardinality) && (horizontal > -zCardinality))
				{
					animator.SetInteger ("Direction", 5);
				}
			}
			else if(vertical > 0)
			{
				if(horizontal >= zCardinality)
				{
					animator.SetInteger ("Direction", 3);
				}
				else if (horizontal <= -zCardinality)
				{
					animator.SetInteger ("Direction", 1);
				}
				else if ((horizontal < zCardinality) && (horizontal > -zCardinality))
				{
					animator.SetInteger ("Direction", 2);
				}
			}
		}*/
		if (controller.isGrounded) {
			moveDirection = new Vector3(horizontal, 0, (vertical * zDepthSpeed));
			moveDirection = transform.TransformDirection(moveDirection);
			moveDirection *= speed;
			if (Input.GetButton("X"))
				moveDirection.y = jumpSpeed;
			if (Input.GetButton("B"))
				Debug.Log("Pressed the B Button!");
			if (Input.GetButton("A"))
				Debug.Log("Pressed the A Button!");
			if (Input.GetButton("Y"))
				Debug.Log("Pressed the Y Button!");
			if (Input.GetButton("Start"))
				Debug.Log("Pressed the Start Button!");
			if (Input.GetButton("Select"))
				Debug.Log("Pressed the Back Button!");
		}
		moveDirection.y -= gravity * Time.deltaTime;
		controller.Move(moveDirection * Time.deltaTime);
	}
}