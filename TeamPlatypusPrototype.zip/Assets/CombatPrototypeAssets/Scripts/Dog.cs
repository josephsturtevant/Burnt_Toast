﻿using UnityEngine;
using System.Collections;

public class Dog : Hero {

	private const int RESOURCE_REGEN_RATE = 20;
	private const int REG_DMG = 30;
	private const int POW_DMG = 60;
	// Use this for initialization
	void Start () {
		
	}
	
	public override int powerAttack(){
		Debug.Log (this.gameObject.name + "Power Attack!");
		if (lowerResource(40)) 
			return POW_DMG;
		else
			return REG_DMG;
	}
	
	public override int regularAttack(){
		Debug.Log (this.gameObject.name + "Regular Attack!");
		return REG_DMG;
	}

	public override void regenResource(bool inGuard){
			increaseResource(RESOURCE_REGEN_RATE);
	}
}
