﻿using UnityEngine;
using System.Collections;

public class CameraScript : MonoBehaviour {
	
	Transform Player = null;
	private Vector3 moveDirection = Vector3.zero;
	public float speed = 10F;
	public float jumpSpeed = 8.0F;
	public float zDepthSpeed = 0.75F;
	float xPos = 0f;
	CharacterController controller = null;

	private float scale = 0.33f;


	void Start()
	{
		Player = GameObject.Find("Player").GetComponent<Transform>();
		xPos = Player.position.x;
		controller = this.GetComponent<CharacterController> ();
	}

	void Update ()
	{
		float vertical = Input.GetAxis("LeftAnalogZ");
		if ((vertical < scale) && (-scale < vertical)) {
			vertical = 0f;
		}
		float horizontal = Input.GetAxis("LeftAnalogX");
		if ((horizontal < scale) && (-scale < horizontal)) {
			horizontal = 0f;
		}
			moveDirection = new Vector3(horizontal, 0, (vertical * zDepthSpeed));
			moveDirection = transform.TransformDirection(moveDirection);
			moveDirection *= speed;
			if (Input.GetButton("A"))
				moveDirection.y = jumpSpeed;
		controller.Move(moveDirection * Time.deltaTime);
		this.transform.position = new Vector3 (Player.position.x, Player.position.y + 1.5f, Player.position.z - 2.5f);
	}	
}
